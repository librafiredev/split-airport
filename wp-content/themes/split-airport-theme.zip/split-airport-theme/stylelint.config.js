module.exports = {
  "extends": [
      "stylelint-config-standard-scss",
      "stylelint-config-prettier-scss"
    ],
  rules: {
    "no-empty-source": null,
    "no-extra-semicolons": true,
    "selector-class-pattern": null
  }
};