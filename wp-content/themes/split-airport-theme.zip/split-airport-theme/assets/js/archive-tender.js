import tenderSingleModal from "../components/tenderSingleModal";

$(function () {

    tenderSingleModal.init();

});