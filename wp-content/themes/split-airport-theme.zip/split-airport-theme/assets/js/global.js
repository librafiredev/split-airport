import navigation from '../components/navigation';
import myFlights from '../components/myFlights';

$(function() {
    navigation.init();
    myFlights.init();
});