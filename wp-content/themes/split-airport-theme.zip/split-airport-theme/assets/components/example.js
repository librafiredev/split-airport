const _this = {

    $dom: {
		
    },

    vars: {
		
	},

    example : function() {

    }

}

export default _this;