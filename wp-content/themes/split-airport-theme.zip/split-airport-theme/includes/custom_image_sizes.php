<?php 

/**
 * Image size 'thumbnail-medium' used on single blog post
 */
// add_image_size( 'thumbnail-medium', 180, 180, true );

?>