<style>

@font-face {
    font-family: 'Zurich BT';
    src: url('<?php echo get_template_directory_uri() ?>/assets/fonts/zurich-bt/ZurichBT.woff2') format('woff2'),
        url('<?php echo get_template_directory_uri() ?>/assets/fonts/zurich-bt/ZurichBT.woff') format('woff');
    font-weight: normal;
    font-style: normal;
    font-display: swap;
}

@font-face {
    font-family: 'Zurich BT';
    src: url('<?php echo get_template_directory_uri() ?>/assets/fonts/zurich-bt/ZurichBTBold.woff2') format('woff2'),
        url('<?php echo get_template_directory_uri() ?>/assets/fonts/zurich-bt/ZurichBTBold.woff') format('woff');
    font-weight: bold;
    font-style: normal;
    font-display: swap;
}

</style>

