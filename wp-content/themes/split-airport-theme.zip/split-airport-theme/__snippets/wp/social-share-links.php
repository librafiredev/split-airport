<a target="_blank" href="https://twitter.com/intent/tweet?text=<?php the_title() ?>&url=<?php the_permalink(); ?>&via=<?php site_url(); ?>">Tweet</a>

<a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>">Share on Facebook</a>

<a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=<?php the_title() ?>&summary=<?php the_excerpt() ?>&source=<?php the_permalink(); ?>">Share on LinkedIn</a>

<a target="_blank" href="https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&description=<?php the_excerpt() ?>&media=<?php the_post_thumbnail_url(); ?>">Pin on Pinterest</a>

<a target="_blank" href="https://vk.com/share.php?url=<?php the_permalink(); ?>&title=<?php the_title() ?>&description=<?php the_excerpt() ?>&image=<?php the_post_thumbnail_url(); ?>&noparse=true">Share on VK</a>

<a target="_blank" href="https://www.xing-share.com/app/user?op=share;sc_p=xing-share;url=<?php the_permalink(); ?>">Share on Xing</a>

<a target="_blank" href="http://www.tumblr.com/share/link?url=<?php the_permalink(); ?>&description=<?php the_excerpt() ?>">Share on Tumblr</a>

<a target="_blank" href="http://www.reddit.com/submit?url=YOUR_URL&title=<?php the_title(); ?>">Share on Reddit</a>