<!-- NOTE: the popup is open when flight-popup-wrapper has "open" class -->
<div class="flight-popup-wrapper">
    <div class="loader"></div>
    <div class="flight-popup-close-area"></div>
    
</div>