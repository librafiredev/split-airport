<div class="tenders-modal-wrapper custom-modal-wrapper">
    <div class="tenders-modal custom-modal"></div>
</div>