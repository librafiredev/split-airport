<?php
extract($args);
if ($warning_message):

?>

    <div class="warning-message">
        <?php echo $warning_message; ?>
    </div>

<?php endif; ?>