<div class="my-flights-root">
    <?php get_template_part('template-parts/blocks/my-flights-dynamic-part'); ?>
</div>

